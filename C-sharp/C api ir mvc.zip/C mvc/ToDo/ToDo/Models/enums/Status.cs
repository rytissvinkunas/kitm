﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ToDo.Models.enums
{
    public enum Status
    {
        New = 10,
        Active = 20,
        Complited = 30,
        Removed = 40
    }
}
