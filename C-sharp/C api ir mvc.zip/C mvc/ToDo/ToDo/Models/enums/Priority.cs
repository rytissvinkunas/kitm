﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ToDo.Models.enums
{
    public enum Priority
    {
        Low = 100,
        Medium = 200,
        High = 300
    }
}
