﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Revolut.Domain.Enums
{
    public enum TransactionMode
    {
        CashIn=300,
        CashOut=400,
        Transfer=500
    }
}
