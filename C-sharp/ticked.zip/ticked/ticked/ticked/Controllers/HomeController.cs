﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ticked.Models;
using ticked.services;
using Microsoft.Extensions.Logging;

namespace ticked.Controllers
{
    public class HomeController : Controller
    {
        private readonly ITicketingServices _service;
        private readonly ILogger<HomeController> _logger;

        public HomeController(ITicketingServices service, ILogger<HomeController> logger)
        {
            _logger = logger;
            _logger.LogDebug(1, "NLog injected into HomeController");
            _service = service;
        }


        //public HomeController(ITicketingServices service)
        //{
        //    _service = service;
        //}

        [HttpGet]
        public IActionResult Index()//
        {
            var machines = _service.GetAllTicketingMachines();
            _logger.LogInformation("Hello, this is the index!");
            return View(machines);
        }
        [HttpPost]
        public IActionResult Index(string moneyIn)
        {
            if (!int.TryParse(moneyIn, out int result))
            {
                return RedirectToAction("Error");
            }
           // ViewBag.Success = "Aciu";
            ViewBag.Success = $"you paid{result} ";
            return View();

        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
