﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using ticked.models;

namespace ticked.data
{
    public class TickedMachineContext:DbContext
    {
        public DbSet<TickedMachine> Machines { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Integrated Security = true; Data Source =.\\SQLEXPRESS; Database = parking");
        }
       
    }
}
