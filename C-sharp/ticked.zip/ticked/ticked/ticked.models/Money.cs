﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ticked.models
{
    public class Money
    {
        public static readonly Money None = new Money(0, 0, 0, 0, 0, 0);//sukuriami objektai pinigu kurie turi savyje 
        public static readonly Money OneCent = new Money(1, 0, 0, 0, 0, 0);
        public static readonly Money TenCent = new Money(0, 1, 0, 0, 0, 0);
        public static readonly Money FiftyCent = new Money(0, 0, 1, 0, 0, 0);
        public static readonly Money OneEuro = new Money(0, 0, 0, 1, 0, 0);
        public static readonly Money FiveEuro = new Money(0, 0, 0, 0, 1, 0);
        public static readonly Money TwentyEuro = new Money(0, 0, 0, 0, 0, 1);

        public int Id { get; set; }
        public int OneCentCount { get; set; }
        public int TenCentCount { get; set; }
        public int FiftyCentCount { get; set; }
        public int OneEuroCount { get; set; }
        public int FiveEuroCount { get; set; }
        public int TwentyEuroCount { get; set; }

        public Money(int oneCent, int tenCent, int fiftyCent, int oneEuro, int fiveEuro, int twentyEuro) : this()
        {
            OneCentCount = oneCent;
            TenCentCount = tenCent;
            FiftyCentCount = fiftyCent;
            OneEuroCount = oneEuro;
            FiveEuroCount = fiveEuro;
            TwentyEuroCount = twentyEuro;
        }
        public Money()
        {
            
        }
    }
}
