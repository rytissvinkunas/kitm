﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ticked.models
{
    public class TickedMachine
    {
        public int Id { get; set; }
        public Money MoneyInside { get; private set; } = Money.None;//None ateina is Money klases 

        public TickedMachine()
        {

        }

    }
}
