﻿using System;
using System.Collections.Generic;
using System.Text;

using ticked.models;

namespace ticked.services
{
    public interface ITicketingServices

    {
        IEnumerable<TickedMachine> GetAllTicketingMachines();
    }
}
