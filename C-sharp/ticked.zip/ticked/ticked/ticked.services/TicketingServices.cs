﻿using System;
using System.Collections.Generic;
using System.Text;
using ticked.models;

namespace ticked.services
{
    public class TicketingServices : ITicketingServices
    {
        public IEnumerable<TickedMachine> GetAllTicketingMachines()
        {
            return null;
        }
    }
}
