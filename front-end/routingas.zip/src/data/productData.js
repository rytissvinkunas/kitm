const productsData = [
    {
        id:1,
        title: "Product 1",
        desc: "Best product in the world",
        img: "img/p1.jpg",
        link:"/p1",
        stock:1
    },
    {
        id:2,
        title: "Product 2",
        desc: "Best product in the world",
        img: "img/p1.jpg",
        link:"/p1",
        stock:0

    },
    {
        id:3,
        title: "Product 3",
        desc: "Best product in the world",
        img: "img/p1.jpg",
        link:"/p1",
        stock:1
    },
    {
        id:4,
        title: "Product 4",
        desc: "Best product in the world",
        img: "img/p1.jpg",
        link:"/p1",
        stock:0,
    },
    {
        id:5,
        title: "Product 5",
        desc: "Best product in the world",
        img: "img/p1.jpg",
        link:"/p1",
        stock:3
    }
];

export default productsData