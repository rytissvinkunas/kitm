import React from 'react';
import styles from './nav.scss';
import {Link} from "react-router-dom";

function Nav() {
    return (
            <div>
                <nav>
                    <ul>
                        <li>
                            <Link to="/">Pagrindinis</Link>
                        </li>
                        <li>
                            <Link to="/produktai">Produktai</Link>
                        </li>
                        <li>
                            <Link to="/kontaktai">Kontaktai</Link>
                        </li>
                    </ul>
                </nav>
            </div>
    );
}

export default Nav;