import React, {Component} from "react"
import styles from './app.scss';
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
} from "react-router-dom";
import Nav from '../nav/Nav';
import Header from '../header/Header';
import Aside from '../aside/Aside';
import Contacts from '../contacts/Contacts';
import Main from '../main/Main';

class App extends Component {
    render() {
        return (
            <div className="container">
                <Header />
                <Nav />
                <Aside/>
                <Main />
            </div>
        );
    }

}
export default App;