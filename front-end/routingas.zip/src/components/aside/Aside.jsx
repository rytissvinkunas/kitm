import React from 'react';
import styles from './aside.scss';
function Aside() {
    return (
        <aside>
            <h3>TODO</h3>
            <ul>
                <li>Learn React....</li>
                <li>Learn React....</li>
                <li>Learn React....</li>
                <li>Learn React....</li>
            </ul>
        </aside>
    );
}

export default Aside;