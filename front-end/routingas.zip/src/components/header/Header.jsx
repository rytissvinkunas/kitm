import React, { Component } from 'react';
import styles from './header.scss';
function Header() {
    return (
        <header className="super">
            <h1>Demo app</h1>
        </header>
    );
}

export default Header;