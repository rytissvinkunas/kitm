import React from 'react';
import { Switch, Route } from 'react-router-dom'
import styles from './main.scss';
import Nav from '../nav/Nav';
import Contacts from '../contacts/Contacts';
import Products from '../products/Products';
import Home from '../home/Home';

const Main = () => (
    <main>
        <Switch>
            <Route exact path='/' component={Home}/>
            <Route path='/produktai' component={Products}/>
            <Route path='/kontaktai' component={Contacts}/>
        </Switch>
    </main>
)


export default Main;