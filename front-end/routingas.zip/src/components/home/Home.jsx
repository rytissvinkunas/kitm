import React, { Component } from 'react';
import styles from './home.scss';
class Home extends Component {
    render(){
        return (
            <section>
                <h1>Pagrindinis puslapis</h1>
                <p>REACT SPA</p>
            </section>
        );
    }

}

export default Home;