import React, { Component } from 'react';
import styles from './products.scss';
import Product from '../product/Product'
import productsData from '../../data/productData';
class Products extends Component{
    constructor(){
        super()
        this.state = {
            products: productsData,
            naujienos:null,
            patiktukai:0
        }
    }
    componentDidMount() {
        fetch('https://www.lrytas.lt/static/json/top_readview_2.json')
            .then(response => response.json())
            .then(data => this.setState({ naujienos:data }));
    }

    render(){
        console.log(this.state.naujienos)
        const productsComponents = this.state.products.map(product =>
            <Product
                key = {product.id}
                title={product.title}
                desc={product.desc}
                img={product.img}
                link={product.link}/>
        );
        return (
            <section className="products">
                <h1>Produktai</h1>
                {productsComponents}
            </section>
        )
    }

}

export default Products;