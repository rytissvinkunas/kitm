import React, { Component } from 'react';
import styles from './product.scss';
class Product extends Component {
    constructor(){
        super()
        this.state={
            patiktukai:0
        }
        this.handleClick = this.handleClick.bind(this)
    }
    handleClick(){
        this.setState(prevState=>{
            return {
                patiktukai:prevState.patiktukai+1
            }
        })
    }
    render(){
        return (
            <div className="product">
                {/*Cia yra komentaras*/}
                <h2>{this.props.title}</h2>
                <p>{this.props.desc}</p>
                <p>{this.props.link}</p>
                <p onClick={this.handleClick}><strong>Patinka</strong></p>
                <p>Patiktukai: <span><h1>{this.state.patiktukai}</h1></span></p>

            </div>
        );
    }

}

export default Product;